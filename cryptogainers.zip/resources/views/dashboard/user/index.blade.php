@extends("layouts.app")
@section('title', 'Profile | CryptoGainers')


@section('content')
    {{-- start:nav --}}
    @include('layouts.nav')
    {{-- end:nav --}}

    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum quos exercitationem dolore illum libero modi nam, nihil
        inventore numquam odio laudantium ab beatae fuga asperiores laboriosam nemo, aspernatur est quo!</p>


    {{-- start:nav --}}
    @include('layouts.footer')
    {{-- end:nav --}}
@endsection
