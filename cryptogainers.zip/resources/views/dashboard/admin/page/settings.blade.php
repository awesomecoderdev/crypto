@extends("dashboard.admin.template")

@section('title', 'Settings | CryptoGainers')

@section('contents')
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Error reprehenderit animi sint eos. Accusamus reprehenderit
        quaerat dolor optio quo. Fugiat, ad quae consequatur earum incidunt dolore ab ex dicta cum.</p>

@endsection
