@extends("dashboard.admin.template")

@section('title', 'Admins | CryptoGainers')

@section('contents')
    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Beatae aliquid deleniti eius, similique reprehenderit,
        commodi laboriosam blanditiis amet, qui numquam quae corporis eos suscipit animi autem distinctio quos eaque quis.
    </p>

@endsection
