@extends("dashboard.admin.template")

@section('title', 'Community | CryptoGainers')

@section('contents')
    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magnam, consectetur possimus quam officia nostrum
        voluptatem ab unde incidunt reprehenderit dolorem fugit ullam et officiis enim omnis minus quaerat! Mollitia,
        doloremque.</p>

@endsection
