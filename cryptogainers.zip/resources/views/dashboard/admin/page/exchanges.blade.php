@extends("dashboard.admin.template")

@section('title', 'Exchanges | CryptoGainers')

@section('contents')

    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, alias laudantium! Corrupti eius eos voluptas ab
        sint ut omnis saepe blanditiis ex? Magni necessitatibus aliquam quasi distinctio neque fugiat veniam!</p>

@endsection
