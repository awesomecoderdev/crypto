@extends("dashboard.admin.main")

@section('contents')
    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Perspiciatis quia sint animi eius incidunt laudantium cumque
    aliquid nisi, doloremque dolores corrupti ducimus facilis possimus, repudiandae dolorem sapiente hic iste molestiae!
@endsection
